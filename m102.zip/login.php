<?php 
	$f3 = require('fatfree-master/lib/base.php');
	
	/* Development DB conn */
	$db_server = 'localhost';
	$db_port = '3306';
	$db_username = 'root';
	$db_password = '666999';
	$db_name = 'M102';
	
	/* Prodcution values */
	/*$db_server = 'sql102.byethost7.com';	
	$db_port = '3306';
	$db_username = 'b7_21018122';
	$db_password = 'm102ourtube';
	$db_name = 'b7_21018122_M102';*/
	
    if(isset($_GET['logout'])) {
        session_start();
        session_unset();
        session_destroy();
        session_write_close();
        setcookie(session_name(), '', 0);
		$f3 = require('fatfree-master/lib/base.php');
		echo $f3->CSRF."<br />";
		$f3->CSRF = "";
		echo $f3->CSRF."<br />";
        echo "Logged out";
        exit();
    }
    
	//function log_user($username, $password) {
		if(isset($_POST["user_id"])) {
			
		}
		if(isset($_POST["username"]) && isset($_POST["password"])) {
			$username = $_POST["username"];
			$password = $_POST["password"];
			$conn = new mysqli($db_server, $db_username, $db_password, $db_name);
			/* check connection */
			if (mysqli_connect_errno()) {
				printf("Connection failed: %s\n", mysqli_connect_error());
				exit();
			}
			
			
            //mysqli_select_db($conn) or die('Cannot select the DB');
            $query = "SELECT user_id, user_password FROM user_login_info WHERE user_login = ?";
			$stmt = $conn->prepare($query);
			/* bind parameters for markers */
			$stmt->bind_param('s', $username);
			/* execute query */
			$stmt->execute();
			/* get results */
			$result = $stmt->get_result();
			/* if results have rows... */
			if ($result->num_rows > 0) {
				$rows = $result->fetch_assoc();
				$stored_password = $rows['user_password'];
				$user_id = $rows['user_id'];
				
				/*echo "User ID: ".$user_id."<br>";
				echo "Stored password: ".$stored_password."<br>";
				echo "Typed password : ".md5($password)."<br>";*/
				
				printf("User ID: %d\nStored password: %s\nTyped password: %s\n", $user_id, $stored_password, md5($password));
				
				$stmt->close();
                $conn->close();
                if (md5($password) == $stored_password) {
                    echo "Password OK!".'<br />';
					$db = $f3->get('DB');
					$db = new DB\SQL('mysql:host='.$db_server.';port='.$db_port.';dbname='.$db_name.';', $db_username, $db_password);
					//$f3->DB = new \DB\SQL\Session($db);					
					//$f3->DB=new DB\SQL('mysql:host=127.0.0.1;port=3306;dbname=M102;','root','666999');
					$session = new DB\SQL\Session($db);//,'sessions',NULL,'CSRF');
					$f3->CSRF = $session->csrf();
					echo $f3->CSRF.'<br />';
					echo $session->csrf().'<br />';
					$f3->copy('CSRF','SESSION.csrf');
					echo $f3->get('SESSION.csrf').'<br />';
					echo $session->sid().'<br />';
					echo $session->ip().'<br />';
					//var_dump($session);
					$f3->set('COOKIE.user', $username, 86400); // 1 day
                    return true;
                } 
                else {
                    echo "Wrong username and/or password.\r\n";
                    //return false;
                }
            }
            else {
				mysqli_close($conn);
                echo "Wrong username and/or password.\r\n";
                //return false;
            }
        }
    //}

?>
<html>
    <head>
        <title>Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="styles/login.css" />
        <script type="text/javascript" src="scripts/jquery/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="scripts/login.js"></script>
    </head>
    <body>
        <script type="text/javascript">
            window.fbAsyncInit = function() {
                FB.init({
                    appId      : '213828052012831',
                    cookie     : true,
                    xfbml      : true,
                    version    : 'v2.8'
                });
                FB.AppEvents.logPageView();   
                checkLoginState();
            };
            (function(d, s, id){
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) {return;}
                js = d.createElement(s); js.id = id;
                js.src = "https://connect.facebook.net/en_US/sdk.js";
                fjs.parentNode.insertBefore(js, fjs);               
            }(document, 'script', 'facebook-jssdk'));
        </script>
        <div class="login centered">
            <h1>Youtube API Search</h1>
            <h2>Login</h2>
            <h2>(M102)</h2>
            <div id="login-form">
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                    <label class="left" for="username">Username</label>
                    <input class="right" type="text" name="username" id="username" value="<?php echo (isset($_POST['username'])) ? $_POST['username'] : $f3->get('COOKIE.user'); ?>" />
					<br /><br />
                    <label class="left" for="password">Password</label>
                    <input class="right" type="password" name="password" id="password" />
                    <br /><br />
<!--                    <button class="left login-btn" onclick="login();">App Login</button>-->
                    <input type="submit" class="left login-btn" value="App Login" />
                    <!--<button class="login-btn" onclick="$('#fb-login-conainer').show();">FB Login</button>-->
                    <!--<button id="login-btn" onclick="checkLoginState();">Login</button>-->
                    <!--<div class="fb-login-button" data-max-rows="1" data-size="large" data-button-type="continue_with" data-show-faces="true" data-auto-logout-link="true" data-use-continue-as="true"></div>-->
                    <span ID="fb-button-span" class="right">
                        <fb:login-button autologoutlink="true"
                            scope="public_profile,email"
                            onlogin="checkLoginState();">
                        </fb:login-button>
                    </span>
                </form>
            </div>
        </div>
        <div id="fb-login-conainer" class="invisible centered">
            <div id="status"></div>
<!--            <div class="fb-login-button" data-max-rows="1" data-size="large" data-button-type="continue_with" data-show-faces="true" data-auto-logout-link="true" data-use-continue-as="true"></div>-->
        </div>
    </body>
</html>
