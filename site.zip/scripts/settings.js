var Settings = (function(sort, length, max) {
	/*var sortBy = sort,
		videoLength = length,
		maxResults = max;
	*/
	return {
		sortBy		: sort,
		videoLength	: length,
		maxResults	: max
	}
})('Relevance', 'Any', 5);